package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.connection.DatabaseConnection;

@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("userName");
		String email = request.getParameter("userEmail");
		String mobile = request.getParameter("userMobile");

		PrintWriter writer = response.getWriter();
		Statement statement = DatabaseConnection.getDatabaseConnection();
		String SQL = "INSERT INTO user_tbl(user_name,user_email,user_mobile)VALUES('" + name + "','" + email + "',"
				+ mobile + ")";
		try {
			
		       int no = statement.executeUpdate(SQL);	
		     if(no > 0) {
		    	
		    	 
		    	 ResultSet resultSet = statement.executeQuery("SELECT * FROM user_tbl");
		    	 ServletContext context =  request.getServletContext();
		    	context.setAttribute("view", resultSet);     
		    	response.sendRedirect(request.getContextPath()+"/view.jsp");
		    }
		    else {
		    	
		    	
		    	writer.println("record is not inserted");
		    }
		} catch (SQLException e) {
			
			
		} 
	}

}
