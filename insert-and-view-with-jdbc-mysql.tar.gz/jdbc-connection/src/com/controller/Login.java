package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.connection.DatabaseConnection;

@WebServlet("/verify")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userName = request.getParameter("userEmail");
		String password = request.getParameter("userPass");
        PrintWriter writer = response.getWriter();
		Statement statement = DatabaseConnection.getDatabaseConnection();
		try {
			String SQL = "SELECT * FROM  user_tbl WHERE user_email='" + userName +"' AND user_name='" + password +"'";
		   System.out.println(SQL);
			ResultSet resultSet = statement.executeQuery(SQL);
		   if(resultSet.next()) {
			   writer.println("login success");
			    
		   }
		   else {
			   writer.print("enter valid username and password"); 
			 
		   }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
